<?php
	define('DB_HOST', '303.itpwebdev.com');
	define('DB_USER', 'jmontema_db_user');
	define('DB_PASS', 'usciscool2022');
	define('DB_NAME', 'jmontema_project_db'); 
?>