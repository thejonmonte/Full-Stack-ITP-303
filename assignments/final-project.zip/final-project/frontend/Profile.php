<?php include("Navbar.php"); ?>

<?php
	if( !isset( $_SESSION["logged_in"] ) || !$_SESSION["logged_in"] ) {
		// Redirect to Home Page
		header("Location: ./HomePage.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>


    	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    	<title>Profile Page</title>
		
		<link href="Profile.css" rel="stylesheet">

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
		<script src="http://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="crossorigin="anonymous"></script>
		<link rel="stylesheet" type="text/css" href="jquery.rateyo.min.css">
		<script>
			var currId = -1;
			window.onload = function() {
				document.querySelector("#nav-home").classList.add("nav-color");
				document.querySelector("#nav-search").classList.add("nav-color");
				document.querySelector("#nav-profile").classList.add("nav-active");

				// Get items from database
			}

			function edit(id) {
				currId = id;
				// Database call to get sets and reps
				let sets = 3;
				let reps = 2;
				document.querySelector("#sets").value = sets;
				document.querySelector("#reps").value = reps;
				$('#exercise-modal').modal('show');
			}

			function deleteItem(id) {
				// Database call to delete item
				document.getElementById(id).remove();
			}

			function alertMe() {
				console.log("HEY");
			}

			function finishEdit() {
				// Add to database
				console.log("Done!");
				let sets = document.querySelector("#sets").value;
				let reps = document.querySelector("#reps").value;
				if (!sets || sets == "" || !reps || reps == "") {
					let response = document.querySelector("#exercise-errors");
					response.classList = "";
					response.classList.add("text-fail");
					response.innerHTML = "Fill out all fields.";
				} else if (isNaN(sets) || isNaN(reps)) {
					let response = document.querySelector("#exercise-errors");
					response.classList = "";
					response.classList.add("text-fail");
					response.innerHTML = "Enter only numbers.";
				} else {
					// Add to database
					let response = document.querySelector("#exercise-errors");
					response.classList = "";
					response.classList.add("text-success");
					response.innerHTML = "Successfully added!";
				}
			}
		</script>  
	</head>

	<body>
		<img class="rounded" src="<?php echo $_SESSION["image"]?>" />
		<h2 class="title"><?php echo $_SESSION["name"]?>'s Workout</h2>
		<div class="info">
				<div class="item">
					      <div class="workout btn btn-outline-light">
								<h3 class="item-title">Hellohellohellohellohellohello</h3>
								<div class="container">
			  					<div class="row">
			  						<div class="col-12 col-sm-12 col-md-6 col-lg-6">
			  							<h4>Sets: 5</h4>
			  						</div>
			  						<div class="col-12 col-sm-12 col-md-6 col-lg-6">
			  							<h4>Reps: 4</h4>
			  						</div>
			  					</div>
			  					<div class="row">
			  						<div class="col-12 col-sm-12 col-md-8 offset-md-6 offset-lg-6 col-lg-8">
			  							<button type="button" class="btn edit-btn" onclick="edit('1')">Edit</button>
			  							<button type="button" class="btn btn-danger delete-btn" onclick="alertMe()">Delete</button>
			  						</div>
			  					</div>
			  				</div>
		               	 </div>
		               	 <div id="2" class="workout btn btn-outline-light">
								<h3 class="item-title">Hellohellohellohellohellohello</h3>
								<div class="container">
			  					<div class="row">
			  						<div class="col-12 col-sm-12 col-md-6 col-lg-6">
			  							<h4>Sets: 5</h4>
			  						</div>
			  						<div class="col-12 col-sm-12 col-md-6 col-lg-6">
			  							<h4>Reps: 4</h4>
			  						</div>
			  					</div>
			  					<div class="row">
			  						<div class="col-12 col-sm-12 col-md-8 offset-md-6 offset-lg-6 col-lg-8">
			  							<button type="button" class="btn edit-btn">Edit</button>
			  							<button type="button" class="btn btn-danger delete-btn" onclick="deleteItem('2')">Delete</button>
			  						</div>
			  					</div>
			  				</div>
		               	 </div>
		        </div>
		</div>

		<div class="modal fade" id="exercise-modal" tabindex="-1" role="dialog"
			aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exercise-modal-title">Edit Workout</h5>
						<button type="button" class="close" data-dismiss="modal"
							aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<input type="text" id="sets" name="sets" placeholder=1 />
						<br /><br />
						<input type="text" id="reps" name="reps" placeholder=2 />
					</div>
					<div class="modal-footer">
						<div id="exercise-errors"></div>
						<button type="button" class="btn btn-light add-btn"
							onclick="finishEdit()">Save</button>
						<button type="button" class="btn btn-light close-btn"
							data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		<script type="text/javascript" src="jquery.min.js"></script> 
		<script type="text/javascript" src="jquery.rateyo.min.js"></script> 
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

		<script>
		</script>
		
	</body>
</html>